package main.clones;

public class Clone1 {
	public void cloneMethod1() {
		System.out.print("1");
		System.out.print("2");
		System.out.print("3");
		System.out.print("4");
		//random
		System.out.print("5");
        System.out.print("6");
	}
	public void cloneMethod2() {
		System.out.print("1");
		System.out.print("2");
		//random
		System.out.print("3");
		System.out.print("4");
		System.out.print("5");
        System.out.print("6");
	}
	
	public void cloneMethod3() {
		System.out.print("1");
		System.out.print("2");
		System.out.print("3");
		System.out.print("4");
		System.out.print("5");
		//random
        System.out.print("6");
	}
	
	public void cloneMethod4() {
		System.out.print("1");
		System.out.print("2");
		System.out.print("3");
		System.out.print("4");
		//random2
		System.out.print("5");
        System.out.print("6");
	}
}
