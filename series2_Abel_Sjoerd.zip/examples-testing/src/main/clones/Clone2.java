package main.clones;

public class Clone2{
	public void dummy1() {
		int x = 1+1;
//		x = 1+1;
//		x = 1+2;
	}
	public void dummy2() {
		int x = 1+1;
//		x = 1+1;
//		x = 1+1;
	}
}
